local List0 = {
}

local Keys = {}



local AbnormalDataCheckTableBase = {

    -- 记录数
	COUNT = 1,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	game_mod = 2,
	head_shot_rate = 10000,
	total_real_kill_num = 4,
	be_other_report = 50,
	avg_real_kill_num = 6,
	check_duration = 70,

    -- 标识常量
}



return AbnormalDataCheckTableBase